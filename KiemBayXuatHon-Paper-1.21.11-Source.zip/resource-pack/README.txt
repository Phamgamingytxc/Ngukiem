MẪU RESOURCE PACK CHO KIẾM 3D
==============================
Plugin đã cấu hình sword-material: DIAMOND_SWORD và sword-custom-model-data: 71001.
Để hiện mô hình kiếm 3D, resource pack của server cần định nghĩa model tương ứng cho
diamond_sword với custom model data 71001. Mỗi phiên bản resource pack có cấu trúc
item model khác nhau; hãy tạo model theo định dạng tương thích Minecraft 1.21.11.

Lưu ý: bản source hiện tại cung cấp cấu hình ID model và hiệu ứng bay cơ bản; để gắn
mô hình kiếm làm phương tiện hiển thị ngay dưới chân/người chơi, cần thêm model display
qua plugin tương thích hoặc phát triển display entity. Plugin thuần Paper không tự tạo
resource pack.
