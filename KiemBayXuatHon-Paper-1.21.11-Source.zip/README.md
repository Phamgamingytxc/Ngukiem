# KiemBayXuatHon — Paper 1.21.11

Plugin độc lập cho Java 21 / Paper 1.21.11, gồm menu tu tiên, ngự kiếm bay cơ bản,
xuất hồn do thám giới hạn theo cảnh giới và quét sinh linh.

## Tính năng
- `/tutien`: mở menu.
- `/kiem bay`: bật/tắt bay; `/kiem tat`; `/kiem tocdo`.
- `/xuathon`: xuất hồn. Giới hạn khoảng cách và thời gian theo cảnh giới.
- `/thuhon`: thu hồn về thân xác.
- `/thanthuc`: quét sinh linh gần vị trí hiện tại.
- `/canhgioi`: xem cảnh giới.
- `/canhgioi <1-9>`: đặt cảnh giới cho bản thân (OP).
- `/canhgioi <player> <1-9>`: đặt cảnh giới người chơi (OP từ console).

## Cảnh giới
1. Luyện Khí, 2. Trúc Cơ, 3. Kim Đan, 4. Nguyên Anh, 5. Hóa Thần,
6. Luyện Hư, 7. Hợp Thể, 8. Đại Thừa, 9. Độ Kiếp.

## Build
Yêu cầu JDK 21 và Maven 3.9+.
1. Giải nén ZIP.
2. Mở terminal tại thư mục có `pom.xml`.
3. Chạy `mvn clean package`.
4. Lấy `target/KiemBayXuatHon-1.0.0.jar`.
5. Chép JAR vào `plugins/` của server Paper 1.21.11 và khởi động lại.

Nếu Maven báo không tìm thấy POM, bạn đang đứng sai thư mục. Dùng `cd` vào đúng thư mục source trước khi chạy lệnh.

## Cấu hình
Sửa `plugins/KiemBayXuatHon/config.yml`, rồi khởi động lại server. Mỗi cảnh giới có khoảng cách xuất hồn và thời gian riêng.

## Lưu ý kỹ thuật
- Dùng Java 21.
- Plugin API-version khai báo 1.21, tương thích nhánh Paper 1.21.x; build phụ thuộc Paper API 1.21.11.
- Bản này là source nền đầy đủ để build. Mô hình kiếm 3D thực tế cần resource pack có model phù hợp; xem `resource-pack/README.txt`.
- Hồn thể dùng ArmorStand hiển thị dấu hiệu linh hồn, còn góc nhìn do thám điều khiển qua nhân vật; đây là triển khai cơ bản, không phải camera thứ hai độc lập.
